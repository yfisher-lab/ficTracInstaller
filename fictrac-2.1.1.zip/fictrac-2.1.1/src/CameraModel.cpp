// /// FicTrac http://rjdmoore.net/fictrac/
// /// \file       CameraModel.h
// /// \brief      Parent class for converting between pixel coords and view vectors.
// /// \author     Saul Thurrowgood
// /// \copyright  CC BY-NC-SA 3.0

// #include "CameraModel.h"

// CameraModel::CameraModel(int width, int height)
	// : _width(width), _height(height)
// {
// }
